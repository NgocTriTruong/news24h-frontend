import React, { useState } from "react";

interface Props {
  onSubmit: (content: string) => void;
}

const CommentForm: React.FC<Props> = ({ onSubmit }) => {
  const [text, setText] = useState("");

  const handleSubmit = () => {
    if (!text.trim()) return;
    onSubmit(text);
    setText("");
  };

  return (
    <div className="mb-4">
      <textarea
        className="w-full border rounded p-2 text-sm"
        rows={3}
        placeholder="Viết bình luận..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button
        onClick={handleSubmit}
        className="mt-2 px-4 py-1 bg-[#78b43d] text-white rounded text-sm"
      >
        Gửi bình luận
      </button>
    </div>
  );
};

export default CommentForm;