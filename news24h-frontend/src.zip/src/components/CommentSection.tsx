// components/comments/CommentSection.tsx
import React, { useEffect, useState } from "react";
import type { Comment } from "../types/CommentType";
import CommentForm from "./CommentForm";
import CommentItem from "./CommentItem";

interface Props {
  articleId: string;
}

const CommentSection: React.FC<Props> = ({ articleId }) => {
  const [comments, setComments] = useState<Comment[]>([]);

  useEffect(() => {
    const data = localStorage.getItem("comments");
    if (data) {
      setComments(JSON.parse(data).filter((c: Comment) => c.articleId === articleId));
    }
  }, [articleId]);

  const save = (newComments: Comment[]) => {
    localStorage.setItem("comments", JSON.stringify(newComments));
    setComments(newComments.filter(c => c.articleId === articleId));
  };

  const addComment = (content: string) => {
    const newComment: Comment = {
      id: "123", // can sua lai theo id 
      articleId,
      author: "Người đọc",
      content,
      createdAt: new Date().toISOString(),
    };

    const all = [...comments, newComment];
    save(all);
  };

  return (
    <div className="mt-10">
      <h2 className="text-lg font-bold mb-3">
        Bình luận ({comments.length})
      </h2>

      <CommentForm onSubmit={addComment} />

      <div className="space-y-2">
        {comments.map((c) => (
          <CommentItem key={c.id} comment={c} />
        ))}
      </div>
    </div>
  );
};

export default CommentSection;
